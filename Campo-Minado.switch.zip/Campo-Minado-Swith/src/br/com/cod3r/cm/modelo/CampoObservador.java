package br.com.cod3r.cm.modelo;

public interface CampoObservador {
	public void eventoOcorreu(Campo campo, CampoEvento evento);


}
